"""
Original code snippets from the following project:
https://github.com/SAGIRI-KAWAII/sagiri-bot
"""
